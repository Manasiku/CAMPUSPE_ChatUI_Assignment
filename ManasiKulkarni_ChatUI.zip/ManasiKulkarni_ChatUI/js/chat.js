const input = document.getElementById("input");
const send = document.getElementById("send");
const chat = document.getElementById("chatArea");
const typing = document.getElementById("typing");
const welcome = document.getElementById("welcome");
const history = document.getElementById("history");

const replies = [
  "Great question!",
  "Let me explain...",
  "Try this approach.",
  "Nice idea!",
  "Keep learning 👍"
];

// ADD MESSAGE
function addMessage(text, type) {
  const div = document.createElement("div");
  div.className = "msg " + type;

  const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

  div.innerHTML = text + `<div class="time">${time}</div>`;
  chat.appendChild(div);

  chat.scrollTop = chat.scrollHeight;
}

// SEND
function sendMessage(text = null) {
  let msg = text || input.value.trim();
  if (!msg) return;

  welcome.style.display = "none";

  addMessage(msg, "user");
  input.value = "";

  typing.style.display = "block";

  setTimeout(() => {
    typing.style.display = "none";
    let res = replies[Math.floor(Math.random() * replies.length)];
    addMessage(res, "ai");
    saveHistory(msg);
  }, 1500);
}

// EVENTS
send.onclick = () => sendMessage();

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// AUTO RESIZE
input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = input.scrollHeight + "px";
});

// QUICK CARDS
function quickMsg(text) {
  sendMessage(text);
}

// SIDEBAR
function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("closed");
}

// NEW CHAT
function newChat() {
  chat.innerHTML = "";
  welcome.style.display = "block";
}

// SAVE HISTORY
function saveHistory(msg) {
  let item = document.createElement("div");
  item.innerText = msg;
  history.appendChild(item);
}